let PGHOST='ep-lively-pine-a5u0oks1.us-east-2.aws.neon.tech'
let PGDATABASE='SenecaDB'
let PGUSER='SenecaDB_owner'
let PGPASSWORD='ipwHkV8WI5ov'

export{
    PGDATABASE,
    PGHOST,
    PGUSER,
    PGPASSWORD
}